from owlready2 import *

# Carregar a ontologia
onto = get_ontology("http://example.org/health.owl")

with onto:
    # Classes (nós principais da ontologia)
    class Doenca(Thing):
        pass

    class Sintoma(Thing):
        pass

    class Tratamento(Thing):
        pass

    class Recomendacao(Thing):
        pass

    # Propriedades (arestas que conectam os nós)
    class tem_sintoma(Doenca >> Sintoma):
        pass

    class tem_tratamento(Doenca >> Tratamento):
        pass

    class tem_recomendacao(Doenca >> Recomendacao):
        pass

# Cria instâncias
with onto:
    febre = Sintoma("febre")
    dor_abdominal = Sintoma("dor_abdominal")
    diarreia = Sintoma("diarreia")
    fadiga = Sintoma("fadiga")
    dor_articulacao = Sintoma("dor_articulacao")
    erupcao_cutanea = Sintoma("erupcao_cutanea")
    nauseas = Sintoma("nauseas")
    vomitos = Sintoma("vomitos")
    ictericia = Sintoma("ictericia")
    inchaco = Sintoma("inchaco")

    covid = Doenca("covid19")
    dengue = Doenca("dengue")
    hepatite = Doenca("hepatite")
    artrite_reumatoide = Doenca("artrite_reumatoide")

    repouso = Tratamento("repouso")
    hidratacao = Tratamento("hidratacao")
    analgesicos = Tratamento("analgesicos")
    antiinflamatorios = Tratamento("antiinflamatorios")
    dieta_controlada = Tratamento("dieta_controlada")

    isolamento = Recomendacao("isolamento")
    medico = Recomendacao("consulta_medica")
    exames = Recomendacao("realizar_exames")
    acompanhamento_regular = Recomendacao("acompanhamento_regular")

    # Atributos das doenças (conexões entre nós)
    covid.tem_sintoma = [febre, fadiga, nauseas]
    covid.tem_tratamento = [repouso, hidratacao]
    covid.tem_recomendacao = [isolamento, medico]

    dengue.tem_sintoma = [febre, dor_articulacao, erupcao_cutanea, fadiga]
    dengue.tem_tratamento = [repouso, hidratacao, analgesicos]
    dengue.tem_recomendacao = [medico, exames]

    hepatite.tem_sintoma = [ictericia, dor_abdominal, nauseas, vomitos]
    hepatite.tem_tratamento = [dieta_controlada, repouso]
    hepatite.tem_recomendacao = [exames, acompanhamento_regular]

    artrite_reumatoide.tem_sintoma = [dor_articulacao, fadiga, inchaco]
    artrite_reumatoide.tem_tratamento = [antiinflamatorios, analgesicos]
    artrite_reumatoide.tem_recomendacao = [acompanhamento_regular, medico]

def consultar_ontologia(sintomas_usuario):
    resultados = []
    for doenca in onto.Doenca.instances():
        sintomas_doenca = [s.name for s in doenca.tem_sintoma]
        if all(sintoma in sintomas_doenca for sintoma in sintomas_usuario):
            resultados.append(doenca)
    return resultados

mapa_sintomas = {
    "febre alta": "febre",
    "dor nas juntas": "dor_articulacao",
    "dores nas articulações": "dor_articulacao",
    "fadiga extrema": "fadiga",
    "enjoo": "nauseas",
    "vômito": "vomitos",
    "pele amarela": "ictericia",
    "cansaço": "fadiga",
}

sintomas_conhecidos = [
    "febre", "dor_abdominal", "diarreia", "fadiga", 
    "dor_articulacao", "erupcao_cutanea", "nauseas", 
    "vomitos", "ictericia"
]

print("Bem-vindo ao sistema de consulta médica!")
print("Por favor, informe os sintomas separados por vírgula (exemplo: febre, fadiga):")
entrada = input("Sintomas: ").strip()

# Normalizar e validar sintomas
sintomas_usuario = [
    mapa_sintomas.get(sintoma.strip().lower(), sintoma.strip().lower())
    for sintoma in entrada.split(",")
]

sintomas_validos = [s for s in sintomas_usuario if s in sintomas_conhecidos]
 
if not sintomas_validos:
    print("Nenhum sintoma válido foi fornecido. Tente novamente.")
else:
    sintomas_invalidos = [s for s in sintomas_usuario if s not in sintomas_conhecidos]
    if sintomas_invalidos:
        print(f"Os seguintes sintomas não foram reconhecidos: {', '.join(sintomas_invalidos)}")
    
    # Consultar a ontologia com sintomas válidos
    if len(sintomas_validos) <= 2:
        print("\nOs sintomas fornecidos não são suficientes para a inteligência fazer um diagnóstico.")
        print("Recomendação: Consulte um médico para uma análise mais crítica.")
    else:
        doencas_encontradas = consultar_ontologia(sintomas_validos)
        if doencas_encontradas:
            print("\nEssas podem ser uma das enfermidades que está interferindo na sua saúde:")
            for doenca in doencas_encontradas:
                print(f"\n- {doenca.name.capitalize()}")
                print("  Sintomas:", ", ".join([s.name for s in doenca.tem_sintoma]))
                print("  Tratamentos:", ", ".join([t.name for t in doenca.tem_tratamento]))
                print("  Recomendações:", ", ".join([r.name for r in doenca.tem_recomendacao]))
        else:
            print("\nNenhuma doença encontrada com base nos sintomas fornecidos.")
            print("Recomendação: Consulte um médico para uma análise mais crítica.")
